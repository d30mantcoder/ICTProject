/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: study_lms
-- ------------------------------------------------------
-- Server version	11.8.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(16) NOT NULL,
  `title` varchar(160) NOT NULL,
  `description` text NOT NULL,
  `instructor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `instructor_id` (`instructor_id`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `instructors` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES
(16,'AITU100','Calculus 1','Демонстрационный курс Calculus 1',16),
(17,'AITU101','Cultural Studies','Демонстрационный курс Cultural Studies',17),
(18,'AITU102','Foreign Language 1','Демонстрационный курс Foreign Language 1',18),
(19,'AITU103','Information and Communication Technologies','Демонстрационный курс Information and Communication Technologies',19),
(20,'AITU104','Introduction to Programming 1','Демонстрационный курс Introduction to Programming 1',20),
(21,'AITU105','Linear Algebra','Демонстрационный курс Linear Algebra',21),
(22,'AITU106','Physical Education','Демонстрационный курс Physical Education',22),
(23,'AITU107','Discrete Mathematics','Демонстрационный курс Discrete Mathematics',23),
(24,'AITU108','Academic Writing','Демонстрационный курс Academic Writing',24),
(25,'AITU109','Physics','Демонстрационный курс Physics',25),
(26,'AITU110','Data Structures','Демонстрационный курс Data Structures',26),
(27,'AITU111','Digital Systems','Демонстрационный курс Digital Systems',27),
(28,'AITU112','Probability and Statistics','Демонстрационный курс Probability and Statistics',28),
(29,'AITU113','History of Kazakhstan','Демонстрационный курс History of Kazakhstan',29),
(30,'AITU114','Algorithms','Демонстрационный курс Algorithms',30);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `progress` int(11) NOT NULL,
  `grade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_student_course` (`student_id`,`course_id`),
  KEY `ix_enrollments_student_id` (`student_id`),
  KEY `ix_enrollments_course_id` (`course_id`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
INSERT INTO `enrollments` VALUES
(1,1,16,62,76),
(2,2,17,35,NULL),
(3,3,18,45,99),
(4,4,19,1,97),
(5,5,20,44,97),
(6,6,21,77,63),
(7,7,22,60,55),
(8,8,23,29,70),
(9,9,24,19,NULL),
(10,10,25,91,73),
(11,11,26,2,NULL),
(12,12,27,53,67),
(13,13,28,38,77),
(14,14,29,65,NULL),
(15,15,30,20,59),
(16,16,16,60,78),
(17,17,17,36,69),
(18,18,18,92,62),
(19,19,19,69,94),
(20,20,20,64,66),
(21,21,21,45,74),
(22,22,22,36,75),
(23,23,23,27,78),
(24,24,24,53,71),
(25,25,25,12,NULL),
(26,26,26,44,68),
(27,27,27,98,94),
(28,28,28,40,95),
(29,29,29,94,90),
(30,30,30,34,66),
(31,31,16,77,93),
(32,32,17,52,94),
(33,33,18,98,NULL),
(34,34,19,83,79),
(35,35,20,62,NULL),
(36,36,21,19,83),
(37,37,22,97,80),
(38,38,23,95,NULL),
(39,39,24,38,87),
(40,40,25,1,57),
(41,41,26,58,83),
(42,42,27,74,87),
(43,43,28,45,68),
(44,44,29,13,83),
(45,45,30,92,72),
(46,46,16,6,94),
(47,47,17,93,74),
(48,48,18,93,74),
(49,49,19,81,68),
(50,50,20,84,NULL),
(51,51,21,47,NULL),
(52,52,22,93,76),
(53,53,23,7,92),
(54,54,24,72,100),
(55,55,25,83,NULL),
(56,56,26,98,94),
(57,57,27,46,NULL),
(58,58,28,57,90),
(59,59,29,19,71),
(60,60,30,87,59),
(61,61,16,61,96),
(62,62,17,99,78),
(63,63,18,64,84),
(64,64,19,42,60),
(65,65,20,57,89),
(66,66,21,72,70),
(67,67,22,95,94),
(68,68,23,61,65),
(69,69,24,11,66),
(70,70,25,93,90);
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES
(13,'SE-101',1),
(14,'SE-102',1),
(15,'SE-103',1),
(16,'SE-201',2),
(17,'SE-202',2),
(18,'SE-203',2),
(19,'SE-301',3),
(20,'SE-302',3),
(21,'SE-303',3),
(22,'SE-401',4),
(23,'SE-402',4),
(24,'SE-403',4);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `instructors`
--

DROP TABLE IF EXISTS `instructors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(80) NOT NULL,
  `last_name` varchar(80) NOT NULL,
  `email` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructors`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `instructors` WRITE;
/*!40000 ALTER TABLE `instructors` DISABLE KEYS */;
INSERT INTO `instructors` VALUES
(16,'Zhanat','Zhuldasov','zhanat.zhuldasov@aitu.demo'),
(17,'Gaukhar','Alzhanova','gaukhar.alzhanova@aitu.demo'),
(18,'Ardakh','Bayan','ardakh.bayan@aitu.demo'),
(19,'Diana','Kazbekova','diana.kazbekova@aitu.demo'),
(20,'Nurtas','Nadirov','nurtas.nadirov@aitu.demo'),
(21,'Anara','Mukhamedina','anara.mukhamedina@aitu.demo'),
(22,'Saltanat','Sadvokassova','saltanat.sadvokassova@aitu.demo'),
(23,'Aibek','Smailov','aibek.smailov@aitu.demo'),
(24,'Aigerim','Tursyn','aigerim.tursyn@aitu.demo'),
(25,'Maksat','Kaliyev','maksat.kaliyev@aitu.demo'),
(26,'Aruzhan','Serik','aruzhan.serik@aitu.demo'),
(27,'Dias','Oraz','dias.oraz@aitu.demo'),
(28,'Madina','Kenzhe','madina.kenzhe@aitu.demo'),
(29,'Timur','Aman','timur.aman@aitu.demo'),
(30,'Dana','Bektas','dana.bektas@aitu.demo');
/*!40000 ALTER TABLE `instructors` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `language` varchar(8) NOT NULL,
  `theme` varchar(16) NOT NULL,
  `notifications_enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_id` (`student_id`),
  CONSTRAINT `preferences_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferences`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
INSERT INTO `preferences` VALUES
(1,1,'ru','dark',0),
(2,2,'en','light',1),
(3,3,'kk','light',1),
(4,4,'ru','light',1),
(5,5,'en','dark',1),
(6,6,'kk','light',0),
(7,7,'ru','light',1),
(8,8,'en','light',1),
(9,9,'kk','dark',1),
(10,10,'ru','light',1),
(11,11,'en','light',0),
(12,12,'kk','light',1),
(13,13,'ru','dark',1),
(14,14,'en','light',1),
(15,15,'kk','light',1),
(16,16,'ru','light',0),
(17,17,'en','dark',1),
(18,18,'kk','light',1),
(19,19,'ru','light',1),
(20,20,'en','light',1),
(21,21,'kk','dark',0),
(22,22,'ru','light',1),
(23,23,'en','light',1),
(24,24,'kk','light',1),
(25,25,'ru','dark',1),
(26,26,'en','light',0),
(27,27,'kk','light',1),
(28,28,'ru','light',1),
(29,29,'en','dark',1),
(30,30,'kk','light',1),
(31,31,'ru','light',0),
(32,32,'en','light',1),
(33,33,'kk','dark',1),
(34,34,'ru','light',1),
(35,35,'en','light',1),
(36,36,'kk','light',0),
(37,37,'ru','dark',1),
(38,38,'en','light',1),
(39,39,'kk','light',1),
(40,40,'ru','light',1),
(41,41,'en','dark',0),
(42,42,'kk','light',1),
(43,43,'ru','light',1),
(44,44,'en','light',1),
(45,45,'kk','dark',1),
(46,46,'ru','light',0),
(47,47,'en','light',1),
(48,48,'kk','light',1),
(49,49,'ru','dark',1),
(50,50,'en','light',1),
(51,51,'kk','light',0),
(52,52,'ru','light',1),
(53,53,'en','dark',1),
(54,54,'kk','light',1),
(55,55,'ru','light',1),
(56,56,'en','light',0),
(57,57,'kk','dark',1),
(58,58,'ru','light',1),
(59,59,'en','light',1),
(60,60,'kk','light',1),
(61,61,'ru','dark',0),
(62,62,'en','light',1),
(63,63,'kk','light',1),
(64,64,'ru','light',1),
(65,65,'en','dark',1),
(66,66,'kk','light',0),
(67,67,'ru','light',1),
(68,68,'en','light',1),
(69,69,'kk','dark',1),
(70,70,'ru','light',1);
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `building` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES
(13,'A-01','AITU корпус A'),
(14,'A-02','AITU корпус A'),
(15,'A-03','AITU корпус A'),
(16,'B-01','AITU корпус B'),
(17,'B-02','AITU корпус B'),
(18,'B-03','AITU корпус B'),
(19,'C-01','AITU корпус C'),
(20,'C-02','AITU корпус C'),
(21,'C-03','AITU корпус C'),
(22,'D-01','AITU корпус D'),
(23,'D-02','AITU корпус D'),
(24,'D-03','AITU корпус D');
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `weekday` int(11) NOT NULL,
  `starts_at` time NOT NULL,
  `ends_at` time NOT NULL,
  `lesson_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `room_id` (`room_id`),
  KEY `ix_schedule_course_id` (`course_id`),
  KEY `ix_schedule_group_id` (`group_id`),
  CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedule_ibfk_3` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES
(1,25,13,14,2,'09:00:00','10:30:00',NULL),
(2,26,13,15,2,'11:00:00','12:30:00',NULL),
(3,27,13,16,2,'13:00:00','14:30:00',NULL),
(4,28,13,17,2,'09:00:00','10:30:00',NULL),
(5,29,13,18,2,'11:00:00','12:30:00',NULL),
(6,28,14,15,3,'09:00:00','10:30:00',NULL),
(7,29,14,16,3,'11:00:00','12:30:00',NULL),
(8,30,14,17,3,'13:00:00','14:30:00',NULL),
(9,16,14,18,3,'09:00:00','10:30:00',NULL),
(10,17,14,19,3,'11:00:00','12:30:00',NULL),
(11,16,15,16,4,'09:00:00','10:30:00',NULL),
(12,17,15,17,4,'11:00:00','12:30:00',NULL),
(13,18,15,18,4,'13:00:00','14:30:00',NULL),
(14,19,15,19,4,'09:00:00','10:30:00',NULL),
(15,20,15,20,4,'11:00:00','12:30:00',NULL),
(16,19,16,17,0,'09:00:00','10:30:00',NULL),
(17,20,16,18,0,'11:00:00','12:30:00',NULL),
(18,21,16,19,0,'13:00:00','14:30:00',NULL),
(19,22,16,20,0,'09:00:00','10:30:00',NULL),
(20,23,16,21,0,'11:00:00','12:30:00',NULL),
(21,22,17,18,1,'09:00:00','10:30:00',NULL),
(22,23,17,19,1,'11:00:00','12:30:00',NULL),
(23,24,17,20,1,'13:00:00','14:30:00',NULL),
(24,25,17,21,1,'09:00:00','10:30:00',NULL),
(25,26,17,22,1,'11:00:00','12:30:00',NULL),
(26,25,18,19,2,'09:00:00','10:30:00',NULL),
(27,26,18,20,2,'11:00:00','12:30:00',NULL),
(28,27,18,21,2,'13:00:00','14:30:00',NULL),
(29,28,18,22,2,'09:00:00','10:30:00',NULL),
(30,29,18,23,2,'11:00:00','12:30:00',NULL),
(31,28,19,20,3,'09:00:00','10:30:00',NULL),
(32,29,19,21,3,'11:00:00','12:30:00',NULL),
(33,30,19,22,3,'13:00:00','14:30:00',NULL),
(34,16,19,23,3,'09:00:00','10:30:00',NULL),
(35,17,19,24,3,'11:00:00','12:30:00',NULL),
(36,16,20,21,4,'09:00:00','10:30:00',NULL),
(37,17,20,22,4,'11:00:00','12:30:00',NULL),
(38,18,20,23,4,'13:00:00','14:30:00',NULL),
(39,19,20,24,4,'09:00:00','10:30:00',NULL),
(40,20,20,13,4,'11:00:00','12:30:00',NULL),
(41,19,21,22,0,'09:00:00','10:30:00',NULL),
(42,20,21,23,0,'11:00:00','12:30:00',NULL),
(43,21,21,24,0,'13:00:00','14:30:00',NULL),
(44,22,21,13,0,'09:00:00','10:30:00',NULL),
(45,23,21,14,0,'11:00:00','12:30:00',NULL),
(46,22,22,23,1,'09:00:00','10:30:00',NULL),
(47,23,22,24,1,'11:00:00','12:30:00',NULL),
(48,24,22,13,1,'13:00:00','14:30:00',NULL),
(49,25,22,14,1,'09:00:00','10:30:00',NULL),
(50,26,22,15,1,'11:00:00','12:30:00',NULL),
(51,25,23,24,2,'09:00:00','10:30:00',NULL),
(52,26,23,13,2,'11:00:00','12:30:00',NULL),
(53,27,23,14,2,'13:00:00','14:30:00',NULL),
(54,28,23,15,2,'09:00:00','10:30:00',NULL),
(55,29,23,16,2,'11:00:00','12:30:00',NULL),
(56,28,24,13,3,'09:00:00','10:30:00',NULL),
(57,29,24,14,3,'11:00:00','12:30:00',NULL),
(58,30,24,15,3,'13:00:00','14:30:00',NULL),
(59,16,24,16,3,'09:00:00','10:30:00',NULL),
(60,17,24,17,3,'11:00:00','12:30:00',NULL);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(80) NOT NULL,
  `last_name` varchar(80) NOT NULL,
  `group_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_students_username` (`username`),
  KEY `ix_students_group_id` (`group_id`),
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES
(1,'student001','$2b$12$ZZRCaV2R4VZW1TMrJyd0wOOYIWYq52Jp9iHvBJKrCSGwzjGJSLfum','Aruzhan','Sarsen',13,1),
(2,'student002','$2b$12$Vk7swA8ayn2z8bZCJjeIteyNISm8.HNrNuk0G0gG8VH67rkiNpkuO','Amina','Tulegen',14,1),
(3,'student003','$2b$12$9HjXHJMofIgZO7J2LaFw0OPGssb06GH6ytt2FCCbe.jg9fO71pDmm','Diana','Yessen',15,1),
(4,'student004','$2b$12$JQBI6XQURHsr3RijRsKMF.cRcK491M3BQZ7cZhfCiCLxCChqFI3AS','Madina','Iskakov',16,1),
(5,'student005','$2b$12$H/1SQ3IFMeFqG2jXUlYAy.OBfueG.wtXhc1NM8qX1HGzEqff4zFLy','Aliya','Kairat',17,1),
(6,'student006','$2b$12$IKY0ELgcNCKxJ1KNPO0zd.ovgYKcaTDctXGS2MFZiKgodpu8a7KI6','Adilet','Bekov',18,1),
(7,'student007','$2b$12$/xG3UpdQtS59Wl8nMam5jOWvhHirupr7KJTXVI.KQQTj5mrWJJB9y','Dias','Abdulla',19,1),
(8,'student008','$2b$12$cHcw41Jd2cR8KKOpEjrvJey7zwvyg0SX5woPL8BjexuAgTR3yRasi','Nursultan','Kassym',20,1),
(9,'student009','$2b$12$y5xrQ2Hv9ZyelA7jh324TeOKJtX5zryvaEvW6a87veKsIDz1r1686','Alikhan','Suleimen',21,1),
(10,'student010','$2b$12$r/wp3leji5gFviF8OZBVSeqVkyTPt/UUUXPB9u.m8ztt8wS81.17G','Sanzhar','Omar',22,1),
(11,'student011','$2b$12$Qkukhwj3XR/S0OG4GrqrauY7Z7c80/2pllku6pqRfDTIJ/K3PXcfi','Miras','Ibrayeva',23,1),
(12,'student012','$2b$12$sNsndXlil9FdsYJm8p17ZeZ.BrDyGpW3hP9LmAyglhN8yNGkj0B2u','Aigerim','Nurgali',24,1),
(13,'student013','$2b$12$V7.ICTmgI2/2Q6q674MQguUcFUCbfey2XRFl1LxW1091hKJrCsZGO','Dana','Zhaksylyk',13,1),
(14,'student014','$2b$12$Q667xruiGI3C8axzOkAbOuGz836h8mABbJC7ADTNCZPoFXv8zDlei','Timur','Akhmet',14,1),
(15,'student015','$2b$12$4UhxWWCnHY.cfBgCndc6BOqPPEcHEhC/EAJfyM5NZcIzc5zLnuBHC','Yerasyl','Murat',15,1),
(16,'student016','$2b$12$6Gl0mzmx/YlKDPyqpCTwQOPiPI21yYyH0mPIIcG7s5oj3PjNOYv7C','Kamila','Sarsen',16,1),
(17,'student017','$2b$12$2Lxt04V4oqtuhU4okRzdO.sxjJvU2w99hRvtmTbj.ciLAq6.U4Xca','Islam','Tulegen',17,1),
(18,'student018','$2b$12$JDY4LY0d.mRcCCYqwMYEEOE.eMY99lHJNA0KhPqL7sMoEe8VIeb02','Zhansaya','Yessen',18,1),
(19,'student019','$2b$12$7LqhJYNWI8RzDU6nEJXbe./SCT4icwuRvIOzSdMKMVHmqji2Ul8ae','Arman','Iskakov',19,1),
(20,'student020','$2b$12$obW9AEP.ZX4h7WBDc2wUgeIhR0HBL74/JYKk.Ih3bnV4AYi8u9sT.','Sabina','Kairat',20,1),
(21,'student021','$2b$12$k2RpNXVtvctnHSjfgEyd6O1oRicgsu9YBCmoH/bXykeiIMHo3wnE6','Aruzhan','Bekov',21,1),
(22,'student022','$2b$12$dbiva6GMb.7o8peWChde/OXhqB66xmthYxVmDyRSFTf3cB8W49uWq','Amina','Abdulla',22,1),
(23,'student023','$2b$12$NOODy6FmEq/Y3qbZh.GGteXoXv9IOstWd/pBEKBbONeLvr39aVo0S','Diana','Kassym',23,1),
(24,'student024','$2b$12$oFbK1gr9nwh8jQNCV4.Px.ZlbmJJyZV9Kiu9M8A3mIvN0N1.3coMC','Madina','Suleimen',24,1),
(25,'student025','$2b$12$jKXdEFP2RIK0BwQi9N.8lOwfi0bLsZzbDnuKV.6sy1qmU.3cxokJK','Aliya','Omar',13,1),
(26,'student026','$2b$12$PJSo36DNUxCCIVngyacrTOoLt0mEMT87KerIVLOgZLuMzTfVn0S2a','Adilet','Ibrayeva',14,1),
(27,'student027','$2b$12$gg/t./aYQPJcuYfWWKpLwuMcfwFeLeKC5.Oz8lcoNMocDckX/GdBa','Dias','Nurgali',15,1),
(28,'student028','$2b$12$qJkbFPvuayhNejNnwtVIkexbxgAJYVtQUQ7zNg3g0kUna.kk.nPCW','Nursultan','Zhaksylyk',16,1),
(29,'student029','$2b$12$BV0PjNtKzCa.WZ8US1w89eqbICTI51MCXT/P/svvjgMkxPcyXXNu2','Alikhan','Akhmet',17,1),
(30,'student030','$2b$12$uKwpBXzR/9.Xmr9hUTiIzOrh9tEdNsUyFU.zV.7ny2VvJWTUChq6e','Sanzhar','Murat',18,1),
(31,'student031','$2b$12$canpl6ylCn.nf26NRqWR9uTxpiwoxs/cV/K/Y3vrpQutnx9ZPgi3W','Miras','Sarsen',19,1),
(32,'student032','$2b$12$65mNX4VvJD/FBtJsurXvEOAlRkHJWsGub8acO/jmZZ2U9dWJXCuhK','Aigerim','Tulegen',20,1),
(33,'student033','$2b$12$uZaZ1FBhxhA4hC2T2ak5MurY1QAk.CIdHXzGQuMai60F1oO.bvlt6','Dana','Yessen',21,1),
(34,'student034','$2b$12$ezCwLNdOZYzQhtbhpKszKuErwOr0rN4RNBhK.hrrvPemPPW99rzJ2','Timur','Iskakov',22,1),
(35,'student035','$2b$12$y4I9i1JMxIe3sNVsEJCLl.J5CNk31AMuLQcV4m5wW7I1SjrCZhUyK','Yerasyl','Kairat',23,1),
(36,'student036','$2b$12$vg1cXcbZ9mcEMGH72F967O1yVpLL0F4vz9vbxI/Pc6c1S3NzFVLpe','Kamila','Bekov',24,1),
(37,'student037','$2b$12$kxBe6xTMT7ydiS62RMtsoeut9xU682nLu1nwKGGaBuf670q/bxUoO','Islam','Abdulla',13,1),
(38,'student038','$2b$12$5FSBRStIUkeLcYcj5i1QKuHTT2DJ.HoJ8SoKbujHjgn5EQtT9Ge/2','Zhansaya','Kassym',14,1),
(39,'student039','$2b$12$sNHAMalqgO9Ur//2IP8zS.WJ0JkS5I91MboXHBO3uUATrMeDBM1E2','Arman','Suleimen',15,1),
(40,'student040','$2b$12$bPQGhRMyBODmysefUC/rmuJz7XurCC5Bkf9QofjwfjiVX42uOrNyS','Sabina','Omar',16,1),
(41,'student041','$2b$12$7p6Rtx0CmZUZd.hQvPvrS.exL.KOzMStjLV4AmBz0lyltDfWcrduS','Aruzhan','Ibrayeva',17,1),
(42,'student042','$2b$12$VgoSOUcbpovibbeQjLtdfu6APMBU0B2/fLp8Vpmsv9sm0yI/WdHfS','Amina','Nurgali',18,1),
(43,'student043','$2b$12$qmz0dc/Y7cIMkT1/VgbWj..N/yuF/Qpg1dkLPczutrpEIPbHq1JOK','Diana','Zhaksylyk',19,1),
(44,'student044','$2b$12$cKOIZtYKRmVxBN/dYhhRs.xXqNG701T5EvYvBGq4K/wUVt8RLhvtu','Madina','Akhmet',20,1),
(45,'student045','$2b$12$nyQpfq9hQH4qxz.emV0qXulVbO8t.xPVEfUppOkZC6WxtqUdrNoBK','Aliya','Murat',21,1),
(46,'student046','$2b$12$ZtnnPGh5WxeatJDGwhYr9.Utix/NYNQuvX79gyIioBRddQjWKcM4e','Adilet','Sarsen',22,1),
(47,'student047','$2b$12$Sbn1YBEJ5AeapLMnW8LUlOGTpyy1yOG4qTlfeiToCUiAU5AIkTIOu','Dias','Tulegen',23,1),
(48,'student048','$2b$12$nIPO4ZPYfkcWgaFwgz6zUeyLkBbXoqOUM3nr7OdlK0wNDTgfyZzhO','Nursultan','Yessen',24,1),
(49,'student049','$2b$12$ootXRoGtptLMNy64iEenYe3rbAByzSSSHtJC3gvDMml/oHTU1KpuK','Alikhan','Iskakov',13,1),
(50,'student050','$2b$12$UFye1jrSfH/on/QowBPsT.dkBdxMpCsFB8Qk/O3B5/bce4K4i5p/K','Sanzhar','Kairat',14,1),
(51,'student051','$2b$12$9b/79Ya6nxlslP07GVA.4.YNynnjbmHAAG3TqCJ9deFtQT1tfW4U.','Miras','Bekov',15,1),
(52,'student052','$2b$12$URTiCJP/klNNXzdQU.JrOex6dw.AaScqBLwxn/2//digymgadi7bm','Aigerim','Abdulla',16,1),
(53,'student053','$2b$12$B0enJBBRFZgaiKgmcm0wu.CUbAY.QlO3P3uyg4DoQYzkqXn932fT6','Dana','Kassym',17,1),
(54,'student054','$2b$12$VE2G17hcZwnKSxZ22TKttODahOb/UnY4IYqTROjwfJxbK/hVBcphy','Timur','Suleimen',18,1),
(55,'student055','$2b$12$nN6Zr7tGCl/XUFMY7NJY8OEjzdDxSFmLBeDcoDZ78Js1gV9J04d96','Yerasyl','Omar',19,1),
(56,'student056','$2b$12$OLx4wa1ZAO8lMO4hi4sEIO0QfaJatDov5.RnXevtpwmhPAlvNFwMG','Kamila','Ibrayeva',20,1),
(57,'student057','$2b$12$GbiqZcZQCNzL6qToTRXx2ua9g4S23BzhgWMLPi1XUigM3iG3GE2eG','Islam','Nurgali',21,1),
(58,'student058','$2b$12$TMrIFYzPxUQji9HNNEq8TuHjv8yjDhm509UanG3QLW95MWuz4cq2C','Zhansaya','Zhaksylyk',22,1),
(59,'student059','$2b$12$VBC5VqrI7CqAib/7rbwaOOgHCi4gOL420.wKBne5UMmkpehtMOihS','Arman','Akhmet',23,1),
(60,'student060','$2b$12$9EBbdX3Vc/vuQQNuzfo3euP4LGWugtCu/occrojnQf3sKAdhNTrQm','Sabina','Murat',24,1),
(61,'student061','$2b$12$a0Ux5yn3HIT1f5WafkPC5uZw4EZjCq6vEO.Sm6/Mh5IBuunlJpr6.','Aruzhan','Sarsen',13,1),
(62,'student062','$2b$12$LxK/05Dxi0bIF1WL.RKrOOezQ0frWOi2uU2o1vZM/hWliO3Ab6ywS','Amina','Tulegen',14,1),
(63,'student063','$2b$12$DwjkPk95WYP/RvhpfetqB.frw7itFIBGYOGNSo6izgoZiFDmzI.TG','Diana','Yessen',15,1),
(64,'student064','$2b$12$KGoJ7ZHC980FuHkYvCXhdOl483pB3Rzn5JTTUFhV3nGqLOb3qYOp.','Madina','Iskakov',16,1),
(65,'student065','$2b$12$ffor6EZWKwg0si6Bd.Lyqejwe8wcpE1pg9RaxVlIaUN.O/K3Px4vi','Aliya','Kairat',17,1),
(66,'student066','$2b$12$jPfbUJnyjymbNmJODy41c.q5zyn.XjSzLK6/RDtZ/1N4eN8Modgk2','Adilet','Bekov',18,1),
(67,'student067','$2b$12$A8G7Lca1ePCEThLt2hq28eOuHjX43hk6fvjmGMjf7AtekozxZlLYa','Dias','Abdulla',19,1),
(68,'student068','$2b$12$WKwowCdnD7rTZN0ywZenAeXxTZQ/fv/vDB3MmOUV8.qotujdU9hMS','Nursultan','Kassym',20,1),
(69,'student069','$2b$12$L/HJbnPwbcLKdyu6Nmbj/.BzP9SG8jtTCEfv9uv/aW2sbD/DABjuS','Alikhan','Suleimen',21,1),
(70,'student070','$2b$12$XofnC0u6j6LHB/87yBRNN.3/wccCa/0XFDKB.cR64HiMz6EQf3som','Sanzhar','Omar',22,1),
(71,'student071','$2b$12$duZPTv30ing5ydrcR0uRnei0FCxSEpnxqJxCZMkCqSEBs6I77AzlC','Miras','Ibrayeva',23,1),
(72,'student072','$2b$12$5FspBxuIrnGbCDQVWvwck.IpW2BZwetxnaccINhgjB/5J3aRup.2u','Aigerim','Nurgali',24,1),
(73,'student073','$2b$12$vqkYmXffCh/tDrbWwV6KUuXatM7RwDPSwcYgbb/T/pU11Gy3gFdvO','Dana','Zhaksylyk',13,1),
(74,'student074','$2b$12$N8LFTu1k295c8XYr1rJdt.QSpiJYAx5.TtyvHMYZ1vW3fEmgzVixq','Timur','Akhmet',14,1),
(75,'student075','$2b$12$IoLJrlPCrvFHm4KGJMCZies1L1svFHW3fqPwA3w3t6JKzEblBpy8e','Yerasyl','Murat',15,1),
(76,'student076','$2b$12$SB1zKjl4gBjl/mAuIen/2O/LTslDeCkRTcL/kYJA7Khp6CV8zxYPS','Kamila','Sarsen',16,1),
(77,'student077','$2b$12$UW1jsFMeuxcBMt20mjuYQOMloGPaHkRG7d4sKYWkR0rbSH7izI64G','Islam','Tulegen',17,1),
(78,'student078','$2b$12$SzSD2b3DqsXivn.9e5OK.eirhUWEC8/ErbqFY/LClShW2KbvoiQP.','Zhansaya','Yessen',18,1),
(79,'student079','$2b$12$N4SEVo35m3Wz6e/kg7tExO0/WfTJ8ug2wBM4uKeL52H2MHt7A3l8i','Arman','Iskakov',19,1),
(80,'student080','$2b$12$6hVgY6xPx2dKks6W.8orwepkfQf8w/TIHREEjz6aUA5086lOD3qhe','Sabina','Kairat',20,1),
(81,'student081','$2b$12$EFHkRlf3.7jhzc4SJn0oceIYsBE7b7z7JuEsnjCCe8qY.pE6k2w8a','Aruzhan','Bekov',21,1),
(82,'student082','$2b$12$lV4XmKK5FnsfVknSYOH25e01QBESK3re8FkWxBwzNywYESqK9xKB.','Amina','Abdulla',22,1),
(83,'student083','$2b$12$/v/5Zs27qwvnnPKSuiDiw.SmXEP8.ZWaMKwS1FzkgjU/h3OvcZWpO','Diana','Kassym',23,1),
(84,'student084','$2b$12$Q4Sv4QJiThxKWuYidz4G6el6kZkR3ulrDu82brgosBmZ8k7wQPDI2','Madina','Suleimen',24,1),
(85,'student085','$2b$12$T1OuzwtQCoreATwr8lkLTe0kap6fLTxsLCCojA5dXFpWDnegyg6AC','Aliya','Omar',13,1),
(86,'student086','$2b$12$PkO1.yzUgGnLAsTHYUZvtemVAwQh3n0CwnP9zqeOtZFL43U57HIHO','Adilet','Ibrayeva',14,1),
(87,'student087','$2b$12$1.Zlbv.bQCKZHwboOnng.ubBCtxr1lYWTnkFR.q4CdXnOscuby/ry','Dias','Nurgali',15,1),
(88,'student088','$2b$12$FHYdvIEtEy5.pSiIutx9C.HUsJN.pMMEew3XoVmVAQp97c3PErNNu','Nursultan','Zhaksylyk',16,1),
(89,'student089','$2b$12$fxLh63n7XEHgPQ3ICX2fZ.QjLU8f0DnMG8QF1F4dUNxQMYnUx9Kaa','Alikhan','Akhmet',17,1),
(90,'student090','$2b$12$Fs5Uzj5N6BfNp8pLPjH73.zbYe5iXjf12nEPhojEuZjBzFR1K9BKa','Sanzhar','Murat',18,1),
(91,'student091','$2b$12$4kWWhKNF9HLSun0jEimebODTG1TTCM/crkpf3InDg7qLE6/D8EzrG','Miras','Sarsen',19,1),
(92,'student092','$2b$12$wysmescno4yhqvLHs.siaOqjIRQwZRyZShHUaRt5CYLPsw3faNyVq','Aigerim','Tulegen',20,1),
(93,'student093','$2b$12$UDoXgdoJ2apf9yrEuDcqWe2QreztONE2c5TIugaao3zCh05vKq0aa','Dana','Yessen',21,1),
(94,'student094','$2b$12$xajod96clzH/K7yNPzJuN.e/e4SMTlDmqHZXa7KQ8JT2lrVzKtwnu','Timur','Iskakov',22,1),
(95,'student095','$2b$12$KRFQ8S2H6zWpumS3kbE8j.Cei0j6VkgKEc61bY8F/Ulrq8jADSCGy','Yerasyl','Kairat',23,1),
(96,'student096','$2b$12$UiFkZlH.TjFeumlqg4jDFu2ghkQp7p.QQWBiAeciYGvTOLq2FZ3Qa','Kamila','Bekov',24,1),
(97,'student097','$2b$12$MqrLeHpN2ouUzKCcN68OpuV4R0jEa1GPLhv/XmeOkK0ooWLHBL7Lq','Islam','Abdulla',13,1),
(98,'student098','$2b$12$.ZRStjTTxI9yq47AOCBPxeuGe55Hu5DoonlkIQOWEQx45wrtSvDj.','Zhansaya','Kassym',14,1),
(99,'student099','$2b$12$2ZsAy1Fmee1E0FzDuU41J.YtT5c5K42eD7s7SQAlEC4JCt5U.bOk6','Arman','Suleimen',15,1),
(100,'student100','$2b$12$4JB0YFmVK4NDqYR.ZbLHruNjMYtTEHq1mBj4FftF7CIdbq8TiyzI6','Sabina','Omar',16,1);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'study_lms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-11 13:23:48
